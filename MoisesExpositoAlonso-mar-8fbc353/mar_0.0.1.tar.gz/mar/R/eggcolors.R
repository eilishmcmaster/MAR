eggcolors<-function(){
  c("#5C2522","#CFA39D", "#B1A980", "#B5DBD9", "#B8DCE8", "#C2C1D3")
}