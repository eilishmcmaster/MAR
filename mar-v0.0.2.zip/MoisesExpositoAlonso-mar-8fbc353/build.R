Rcpp::compileAttributes()
